package controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

public class loginController implements Initializable{
	
	
	@FXML
    private void handleCloseAction(ActionEvent event) {			// Close Button Handler
		Platform.exit();
    }
	
	@FXML
    private void handleSignInAction(ActionEvent event) {		// SignIn Button Handler
		
    }
	
	@Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
    }   
}
